/**
 * Entity beans from dina database
 */
package se.nrm.dina.datamodel;
