/**
 * Help class for dina-datamodel
 */
package se.nrm.dina.datamodel.util;
